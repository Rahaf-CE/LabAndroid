package com.example.projectlabandroid;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ReservationManager {
    private static final String PREF_NAME = "reservation_pref";
    private static final String KEY_RESERVATIONS = "key_reservations";
    private SharedPreferences prefs;
    private Gson gson;

    public ReservationManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
    }

    public void addReservation(Reservation reservation) {
        List<Reservation> reservations = getAllReservations();
        reservations.add(reservation);
        saveReservations(reservations);
    }

    public List<Reservation> getAllReservations() {
        String json = prefs.getString(KEY_RESERVATIONS, null);
        if (json == null) return new ArrayList<>();
        Type type = new TypeToken<List<Reservation>>() {}.getType();
        return gson.fromJson(json, type);
    }

    public void saveReservations(List<Reservation> reservations) {
        String json = gson.toJson(reservations);
        prefs.edit().putString(KEY_RESERVATIONS, json).apply();
    }

    public void clearReservations() {
        prefs.edit().remove(KEY_RESERVATIONS).apply();
    }
}
