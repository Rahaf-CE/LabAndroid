package com.example.projectlabandroid;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.app.Activity;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.bumptech.glide.Glide;
import com.example.projectlabandroid.DataBaseHelper;
import com.example.projectlabandroid.R;

import java.util.regex.Pattern;


public class ProfileManagmentFragment extends Fragment {

    EditText firstNameEdit, lastNameEdit, phoneEdit, passwordEdit;
    ImageView profileImage;
    Button updateBtn, chooseImageBtn;
    Uri selectedImageUri;
    String loggedInEmail;
    DataBaseHelper db;
    final int PICK_IMAGE_REQUEST = 1;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile_managment, container, false);

        firstNameEdit = view.findViewById(R.id.editFirstName);
        lastNameEdit = view.findViewById(R.id.editLastName);
        phoneEdit = view.findViewById(R.id.editPhone);
        passwordEdit = view.findViewById(R.id.editPassword);
        profileImage = view.findViewById(R.id.profileImage);
        updateBtn = view.findViewById(R.id.btnUpdate);
        chooseImageBtn = view.findViewById(R.id.btnChooseImage);

        db = new DataBaseHelper(getContext());

        SharedPreferences prefs = requireActivity().getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE);
        loggedInEmail = prefs.getString("loggedInEmail", null);

        if (loggedInEmail != null) {
            String[] user = db.getUserDetails(loggedInEmail);
            firstNameEdit.setText(user[0]);
            lastNameEdit.setText(user[1]);
            phoneEdit.setText(user[2]);
            passwordEdit.setText(user[3]);

            String imageUri = prefs.getString("profileImageUri_" + loggedInEmail, null);
            if (imageUri != null) {
                Glide.with(this).load(Uri.parse(imageUri)).into(profileImage);
                selectedImageUri = Uri.parse(imageUri);
            }
        }

        chooseImageBtn.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, PICK_IMAGE_REQUEST);
        });

        updateBtn.setOnClickListener(v -> handleUpdate());

        return view;
    }

    private void handleUpdate() {
        String fname = firstNameEdit.getText().toString().trim();
        String lname = lastNameEdit.getText().toString().trim();
        String phone = phoneEdit.getText().toString().trim();
        String password = passwordEdit.getText().toString();

        if (fname.length() < 3 || lname.length() < 3) {
            Toast.makeText(getContext(), "Names must be at least 3 characters", Toast.LENGTH_SHORT).show();
            return;
        }


        if (!Pattern.matches("^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@#$%^&+=!]).{6,}$", password)) {
            passwordEdit.setError("Password must be 6+ chars, with 1 letter, 1 number, 1 special char");
            return;
        }

        boolean updated = db.updateUser(loggedInEmail, fname, lname, phone, password);

        if (selectedImageUri != null) {
            SharedPreferences.Editor editor = requireActivity()
                    .getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE).edit();
            editor.putString("profileImageUri_" + loggedInEmail, selectedImageUri.toString());
            editor.apply();
        }

        Toast.makeText(getContext(), updated ? "Profile updated" : "Update failed", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            selectedImageUri = data.getData();
            Glide.with(this).load(selectedImageUri).into(profileImage);
        }
    }
}