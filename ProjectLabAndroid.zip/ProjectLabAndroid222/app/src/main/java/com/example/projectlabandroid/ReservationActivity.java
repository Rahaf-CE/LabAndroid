package com.example.projectlabandroid;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ReservationActivity extends AppCompatActivity {

    TextView txtTitle, txtLocation, txtPrice, txtDateTime;
    Button btnConfirm;
    ImageView imgProperty;
    String userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation);

        Property property = (Property) getIntent().getSerializableExtra("property");


        if (property == null || property.isHeader()) {
            Toast.makeText(this, "Invalid property selected for reservation.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }


        txtTitle = findViewById(R.id.txtResTitle);
        txtLocation = findViewById(R.id.txtResLocation);
        txtPrice = findViewById(R.id.txtResPrice);
        txtDateTime = findViewById(R.id.txtResDateTime);
        btnConfirm = findViewById(R.id.btnConfirmReservation);
        imgProperty = findViewById(R.id.imgResProperty);

        txtTitle.setText(property.getTitle());
        txtLocation.setText(property.getLocation());
        txtPrice.setText("$" + property.getPrice());
        Glide.with(this).load(property.getImageUrl()).into(imgProperty);

        String dateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());
        txtDateTime.setText(dateTime);

        SharedPreferences prefs = getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE);
        userEmail = prefs.getString("loggedInEmail", null);

        btnConfirm.setOnClickListener(v -> {
            if (userEmail == null) {
                Toast.makeText(this, "Please log in to confirm reservation.", Toast.LENGTH_SHORT).show();
                return;
            }

            SharedPrefManager sharedPrefManager = new SharedPrefManager(this);
            sharedPrefManager.saveReservation(property);

            Toast.makeText(this, "Reservation confirmed!", Toast.LENGTH_LONG).show();
            finish();
        });

    }
}
