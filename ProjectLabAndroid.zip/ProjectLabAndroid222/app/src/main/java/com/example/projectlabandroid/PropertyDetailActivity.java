package com.example.projectlabandroid;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;

public class PropertyDetailActivity extends AppCompatActivity {

    TextView txtTitle, txtLocation, txtPrice, txtDetails;
    ImageView imgProperty;
    Button btnReserve, btnFavorite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_property_detail);

        Property property = (Property) getIntent().getSerializableExtra("property");

        txtTitle = findViewById(R.id.txtTitleDetail);
        txtLocation = findViewById(R.id.txtLocationDetail);
        txtPrice = findViewById(R.id.txtPriceDetail);
        txtDetails = findViewById(R.id.txtFullDescription);
        imgProperty = findViewById(R.id.imgPropertyDetail);
        btnReserve = findViewById(R.id.btnReserve);
        btnFavorite = findViewById(R.id.btnFavorite);

        txtTitle.setText(property.getTitle());
        txtLocation.setText(property.getLocation());
        txtPrice.setText("$" + property.getPrice());
        txtDetails.setText(property.getDescription());
        Glide.with(this).load(property.getImageUrl()).into(imgProperty);

        btnReserve.setOnClickListener(v ->
                Toast.makeText(this, "Reserved " + property.getTitle(), Toast.LENGTH_SHORT).show());

        btnFavorite.setOnClickListener(v ->
                Toast.makeText(this, "Added to favorites", Toast.LENGTH_SHORT).show());
    }
}
