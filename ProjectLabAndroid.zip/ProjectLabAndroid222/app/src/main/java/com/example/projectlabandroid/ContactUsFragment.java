package com.example.projectlabandroid;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.*;
import android.widget.Button;
import androidx.fragment.app.Fragment;
import com.example.projectlabandroid.R;

public class ContactUsFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_contact_us, container, false);

        Button callBtn = view.findViewById(R.id.btnCall);
        Button mapBtn = view.findViewById(R.id.btnMap);
        Button emailBtn = view.findViewById(R.id.btnEmail);

        // Call
        callBtn.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:+970599000000"));
            startActivity(intent);
        });

        // Map
        mapBtn.setOnClickListener(v -> {
            String location = "Real Estate Hub, Ramallah";
            Uri gmmIntentUri = Uri.parse("geo:0,0?q=" + Uri.encode(location));
            Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
            mapIntent.setPackage("com.google.android.apps.maps");
            startActivity(mapIntent);
        });

        // Email
        emailBtn.setOnClickListener(v -> {
            Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
            emailIntent.setData(Uri.parse("mailto:RealEstateHub@agency.com"));
            emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Inquiry from App");
            startActivity(Intent.createChooser(emailIntent, "Send Email"));
        });

        return view;
    }
}
