package com.example.projectlabandroid;

import java.io.Serializable;

public class ReservationItem implements Serializable {
    private Property property;
    private long timestamp;

    public ReservationItem(Property property, long timestamp) {
        this.property = property;
        this.timestamp = timestamp;
    }

    public Property getProperty() {
        return property;
    }

    public long getTimestamp() {
        return timestamp;
    }
}
