package com.example.projectlabandroid;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.*;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.*;

import java.util.*;

public class FeaturedPropertiesFragment extends Fragment {

    private RecyclerView recyclerView;
    private SharedPrefManager sharedPrefManager;
    private DataBaseHelper db;
    private String email;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_featured_properties, container, false);
        recyclerView = view.findViewById(R.id.recyclerFeatured);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        sharedPrefManager = new SharedPrefManager(getContext());
        db = new DataBaseHelper(getContext());

        SharedPreferences prefs = getContext().getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE);
        email = prefs.getString("loggedInEmail", null);

        List<Property> allProperties = PropertyRepository.getAll();
        List<Property> featuredList = new ArrayList<>();
        for (Property p : allProperties) {
            if (p.isFeatured()) {
                featuredList.add(p);
            }
        }

        PropertyAdapter adapter = new PropertyAdapter(getContext(), featuredList, new PropertyAdapter.OnPropertyClickListener() {
            @Override
            public void onPropertyClick(Property property) {
                Intent intent = new Intent(getContext(), PropertyDetailActivity.class);
                intent.putExtra("property", property);
                startActivity(intent);
            }

            @Override
            public void onReserveClick(Property property) {
                sharedPrefManager.saveReservation(property);
                Intent intent = new Intent(getContext(), ReservationActivity.class);
                intent.putExtra("property", property);
                startActivity(intent);
            }

            @Override
            public void onFavoriteClick(Property property) {
                sharedPrefManager.saveFavorite(property);
                Toast.makeText(getContext(), "Added to favorites", Toast.LENGTH_SHORT).show();
            }
        });

        recyclerView.setAdapter(adapter);
        return view;
    }
}
