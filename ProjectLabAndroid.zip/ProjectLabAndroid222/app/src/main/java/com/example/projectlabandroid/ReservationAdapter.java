package com.example.projectlabandroid;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ReservationAdapter extends RecyclerView.Adapter<ReservationAdapter.ViewHolder> {

    private Context context;
    private List<ReservationItem> reservationList;

    public ReservationAdapter(Context context, List<ReservationItem> reservationList) {
        this.context = context;
        this.reservationList = reservationList;
    }

    @NonNull
    @Override
    public ReservationAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_reservation, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReservationAdapter.ViewHolder holder, int position) {
        ReservationItem item = reservationList.get(position);
        Property property = item.getProperty();

        holder.title.setText(property.getTitle());
        holder.location.setText(property.getLocation());
        holder.price.setText("$" + property.getPrice());

        String dateStr = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                .format(new Date(item.getTimestamp()));
        holder.dateTime.setText(dateStr);

        Glide.with(context).load(property.getImageUrl()).into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return reservationList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, location, price, dateTime;
        ImageView imageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.txtResTitle);
            location = itemView.findViewById(R.id.txtResLocation);
            price = itemView.findViewById(R.id.txtResPrice);
            dateTime = itemView.findViewById(R.id.txtResDateTime);
            imageView = itemView.findViewById(R.id.imgResProperty);
        }
    }
}
