package com.example.projectlabandroid;



import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.*;

public class SharedPrefManager {
    private static final String PREF_NAME = "RealEstateApp.db";
    private static final String FAVORITES_PREF = "favorites";
    private static final String RESERVATIONS_PREF = "reservations";

    private SharedPreferences sharedPreferences;
    private SharedPreferences favoritePrefs;
    private SharedPreferences reservationPrefs;

    private SharedPreferences.Editor editor;
    private Context context;
    private Gson gson;

    public SharedPrefManager(Context context) {
        this.context = context;
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        favoritePrefs = context.getSharedPreferences(FAVORITES_PREF, Context.MODE_PRIVATE);
        reservationPrefs = context.getSharedPreferences(RESERVATIONS_PREF, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    // Session (user) management
    public void saveEmail(String email) {
        editor.putString("email", email);
        editor.apply();
    }

    public String getEmail() {
        return sharedPreferences.getString("email", null);
    }

    public void logout() {
        editor.clear();
        editor.apply();
    }

    // Favorite management
    public void saveFavorite(Property property) {
        Gson gson = new Gson();
        String json = gson.toJson(property);
        favoritePrefs.edit().putString(property.getId(), json).apply();
    }

    public void removeFavorite(String propertyId) {
        favoritePrefs.edit().remove(propertyId).apply();
    }

    public boolean isFavorite(String propertyId) {
        return favoritePrefs.contains(propertyId);
    }

    public List<Property> getFavoriteProperties() {
        Map<String, ?> allEntries = favoritePrefs.getAll();
        List<Property> favorites = new ArrayList<>();
        Gson gson = new Gson();
        for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
            String json = entry.getValue().toString();
            Property property = gson.fromJson(json, Property.class);
            favorites.add(property);
        }
        return favorites;
    }

    public void clearFavorites() {
        favoritePrefs.edit().clear().apply();
    }

    // Reservation management


    public void saveReservation(Property property) {
        List<ReservationItem> reservations = getReservations();
        reservations.add(new ReservationItem(property, System.currentTimeMillis()));
        saveReservationList(reservations);
    }

    private void saveReservationList(List<ReservationItem> list) {
        Gson gson = new Gson();
        String json = gson.toJson(list);
        sharedPreferences.edit().putString("reservations", json).apply();
    }

    public List<ReservationItem> getReservations() {
        String json = sharedPreferences.getString("reservations", "");
        Type type = new TypeToken<List<ReservationItem>>() {}.getType();
        return json.isEmpty() ? new ArrayList<>() : new Gson().fromJson(json, type);
    }



    public void clearReservations() {
        editor.remove(RESERVATIONS_PREF).apply();
    }


}