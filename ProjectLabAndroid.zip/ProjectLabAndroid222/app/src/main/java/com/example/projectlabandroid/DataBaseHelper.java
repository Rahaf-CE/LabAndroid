package com.example.projectlabandroid;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.icu.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class DataBaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "RealEstateApp.db";
    private static final int DB_VERSION = 2; // Bumped version
    public static final String TABLE_RESERVATIONS = "reservations";
    public static final String COL_RES_EMAIL = "email";
    public static final String COL_RES_TITLE = "title";
    public static final String COL_RES_LOCATION = "location";
    public static final String COL_RES_PRICE = "price";
    public static final String COL_RES_DATE_TIME = "date_time";
    public static final String COL_RES_IMAGE_URL = "image_url";


    public static final String TABLE_USERS = "users";
    public static final String COL_EMAIL = "email";
    public static final String COL_FIRST_NAME = "first_name";
    public static final String COL_LAST_NAME = "last_name";
    public static final String COL_PASSWORD = "password";
    public static final String COL_PHONE = "phone";
    public static final String COL_GENDER = "gender";
    public static final String COL_COUNTRY = "country";
    public static final String COL_CITY = "city";
    public static final String COL_ROLE = "role"; // "admin" or "user"

    public static final String TABLE_FAVORITES = "favorites";
    public static final String COL_FAV_EMAIL = "user_email";
    public static final String COL_PROPERTY_ID = "property_id";

    public DataBaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE reservations (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "email TEXT, " +
                "title TEXT, " +
                "location TEXT, " +
                "price TEXT, " +
                "date_time TEXT, " +
                "image_url TEXT)");

        // Users table
        String createUserTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_EMAIL + " TEXT PRIMARY KEY, " +
                COL_FIRST_NAME + " TEXT, " +
                COL_LAST_NAME + " TEXT, " +
                COL_PASSWORD + " TEXT, " +
                COL_PHONE + " TEXT, " +
                COL_GENDER + " TEXT, " +
                COL_COUNTRY + " TEXT, " +
                COL_CITY + " TEXT, " +
                COL_ROLE + " TEXT)";
        db.execSQL(createUserTable);

        // Default admin
        String insertAdmin = "INSERT INTO " + TABLE_USERS + " VALUES (" +
                "'admin@admin.com', 'Admin', 'User', 'Admin123!', '0000000000', 'Other', 'AdminLand', 'AdminCity', 'admin')";
        db.execSQL(insertAdmin);

        // Favorites table
        String createFavoritesTable = "CREATE TABLE " + TABLE_FAVORITES + " (" +
                COL_FAV_EMAIL + " TEXT, " +
                COL_PROPERTY_ID + " TEXT, " +
                "PRIMARY KEY(" + COL_FAV_EMAIL + ", " + COL_PROPERTY_ID + "))";
        db.execSQL(createFavoritesTable);

    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FAVORITES);
        onCreate(db);
    }



    public boolean insertUser(String email, String fname, String lname, String password, String phone,
                              String gender, String country, String city) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_EMAIL, email);
        values.put(COL_FIRST_NAME, fname);
        values.put(COL_LAST_NAME, lname);
        values.put(COL_PASSWORD, password);
        values.put(COL_PHONE, phone);
        values.put(COL_GENDER, gender);
        values.put(COL_COUNTRY, country);
        values.put(COL_CITY, city);
        values.put(COL_ROLE, "user");

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    public boolean validateUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " +
                COL_EMAIL + "=? AND " + COL_PASSWORD + "=?", new String[]{email, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public String getUserRole(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COL_ROLE + " FROM " + TABLE_USERS +
                " WHERE " + COL_EMAIL + "=?", new String[]{email});
        String role = "user";
        if (cursor.moveToFirst()) {
            role = cursor.getString(0);
        }
        cursor.close();
        return role;
    }

    public boolean isUserExists(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COL_EMAIL + " FROM " + TABLE_USERS +
                " WHERE " + COL_EMAIL + "=?", new String[]{email});
        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    // === Favorites ===
    public void addFavorite(String email, String propertyId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_FAV_EMAIL, email);
        values.put(COL_PROPERTY_ID, propertyId);
        db.insertWithOnConflict(TABLE_FAVORITES, null, values, SQLiteDatabase.CONFLICT_IGNORE);
    }

    public void removeFavorite(String email, String propertyId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_FAVORITES, COL_FAV_EMAIL + "=? AND " + COL_PROPERTY_ID + "=?",
                new String[]{email, propertyId});
    }

    public boolean isFavorite(String email, String propertyId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_FAVORITES, null, COL_FAV_EMAIL + "=? AND " + COL_PROPERTY_ID + "=?",
                new String[]{email, propertyId}, null, null, null);
        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    public List<String> getUserFavorites(String email) {
        List<String> propertyIds = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_FAVORITES, new String[]{COL_PROPERTY_ID},
                COL_FAV_EMAIL + "=?", new String[]{email}, null, null, null);
        while (cursor.moveToNext()) {
            propertyIds.add(cursor.getString(0));
        }
        cursor.close();
        return propertyIds;
    }



    public String[] getUserDetails(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT first_name, last_name, phone, password FROM users WHERE email=?", new String[]{email});
        String[] user = new String[4];
        if (cursor.moveToFirst()) {
            user[0] = cursor.getString(0);
            user[1] = cursor.getString(1);
            user[2] = cursor.getString(2);
            user[3] = cursor.getString(3);
        }
        cursor.close();
        return user;
    }

    public boolean updateUser(String email, String fname, String lname, String phone, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("first_name", fname);
        values.put("last_name", lname);
        values.put("phone", phone);
        values.put("password", password);
        int rows = db.update("users", values, "email=?", new String[]{email});
        return rows > 0;
    }


    public void addReservation(String email, String title, String location, String price, String dateTime, String imageUrl) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_RES_EMAIL, email);
        values.put(COL_RES_TITLE, title);
        values.put(COL_RES_LOCATION, location);
        values.put(COL_RES_PRICE, price);
        values.put(COL_RES_DATE_TIME, dateTime);
        values.put(COL_RES_IMAGE_URL, imageUrl);

        db.insertWithOnConflict(TABLE_RESERVATIONS, null, values, SQLiteDatabase.CONFLICT_IGNORE);
    }


    public List<String> getUserReservations(String email) {
        List<String> reservationTitles = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_RESERVATIONS, new String[]{COL_RES_TITLE},
                COL_RES_EMAIL + "=?", new String[]{email}, null, null, null);
        while (cursor.moveToNext()) {
            reservationTitles.add(cursor.getString(0));
        }
        cursor.close();
        return reservationTitles;
    }

}
