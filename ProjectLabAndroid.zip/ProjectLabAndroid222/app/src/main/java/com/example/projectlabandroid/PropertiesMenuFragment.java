package com.example.projectlabandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class PropertiesMenuFragment extends Fragment {

    private RecyclerView recyclerView;
    private PropertyAdapter adapter;
    private Spinner typeSpinner;
    private EditText locationSearch;
    private EditText minPriceInput, maxPriceInput;
    private List<Property> allProperties;
    private SharedPrefManager sharedPrefManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_properties_menu, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewProperties);
        typeSpinner = view.findViewById(R.id.spinnerPropertyType);
        locationSearch = view.findViewById(R.id.editTextLocationSearch);
        minPriceInput = view.findViewById(R.id.editTextMinPrice);
        maxPriceInput = view.findViewById(R.id.editTextMaxPrice);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        sharedPrefManager = new SharedPrefManager(getContext());

        allProperties = PropertyRepository.getAll();
        setupSpinner();
        displayGroupedProperties(allProperties);

        return view;
    }

    private void setupSpinner() {
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, new String[]{"All", "Apartment", "Villa", "Land"});
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        typeSpinner.setAdapter(spinnerAdapter);

        typeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                applyFilters();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void applyFilters() {
        String selectedType = typeSpinner.getSelectedItem().toString();
        String locationText = locationSearch.getText().toString().toLowerCase().trim();
        String minPriceText = minPriceInput.getText().toString().trim();
        String maxPriceText = maxPriceInput.getText().toString().trim();

        if (selectedType.equals("All") && locationText.isEmpty() && minPriceText.isEmpty() && maxPriceText.isEmpty()) {
            displayGroupedProperties(allProperties);
            return;
        }


        double minPrice = minPriceText.isEmpty() ? 0 : Double.parseDouble(minPriceText);
        double maxPrice = maxPriceText.isEmpty() ? Double.MAX_VALUE : Double.parseDouble(maxPriceText);

        List<Property> filteredList = new ArrayList<>();

        for (Property p : allProperties) {
            boolean matchesType = selectedType.equals("All") || p.getType().equalsIgnoreCase(selectedType);
            boolean matchesLocation = locationText.isEmpty() || p.getLocation().toLowerCase().contains(locationText);
            boolean matchesPrice = p.getPrice() >= minPrice && p.getPrice() <= maxPrice;

            if (matchesType && matchesLocation && matchesPrice) {
                filteredList.add(p);
            }
        }

        displayGroupedProperties(filteredList);
    }

    private void displayGroupedProperties(List<Property> sourceList) {
        Map<String, List<Property>> groupedMap = new LinkedHashMap<>();

        for (Property p : sourceList) {
            if (!groupedMap.containsKey(p.getType())) {
                groupedMap.put(p.getType(), new ArrayList<>());
            }
            groupedMap.get(p.getType()).add(p);
        }

        List<Property> groupedList = new ArrayList<>();
        for (Map.Entry<String, List<Property>> entry : groupedMap.entrySet()) {
            groupedList.addAll(entry.getValue());
        }

        adapter = new PropertyAdapter(getContext(), groupedList, new PropertyAdapter.OnPropertyClickListener() {
            @Override
            public void onPropertyClick(Property property) {
                Intent intent = new Intent(getContext(), PropertyDetailActivity.class);
                intent.putExtra("property", property);
                startActivity(intent);
            }

            @Override
            public void onReserveClick(Property property) {
                Intent intent = new Intent(getContext(), ReservationActivity.class);
                intent.putExtra("property", property);
                startActivity(intent);
            }


            @Override
            public void onFavoriteClick(Property property) {
                sharedPrefManager.saveFavorite(property);
                Toast.makeText(getContext(), "Added to Favorites", Toast.LENGTH_SHORT).show();
            }

        });

        recyclerView.setAdapter(adapter);
    }
}