package com.example.projectlabandroid;

import java.io.Serializable;

public class Property implements Serializable {
    private String id;
    private String title;
    private String description;
    private double price;
    private String location;
    private String imageUrl;
    private String type;
    private boolean isHeader = false;

    private boolean isFeatured = false;



    public Property(String id, String title, String description, double price, String location, String imageUrl) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.price = price;
        this.location = location;
        this.imageUrl = imageUrl;
        this.type = "";
    }
    public boolean isFeatured() {
        return isFeatured;
    }

    public void setFeatured(boolean featured) {
        isFeatured = featured;
    }
    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public double getPrice() {
        return price;
    }

    public String getLocation() {
        return location;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isHeader() {
        return isHeader;
    }

    public void setIsHeader(boolean isHeader) {
        this.isHeader = isHeader;
    }

    public String getDateTime() {
        return "";
    }
}
