package com.example.projectlabandroid;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class PropertyAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_PROPERTY = 1;

    private Context context;
    private List<Property> properties;
    private OnPropertyClickListener listener;

    public interface OnPropertyClickListener {
        void onPropertyClick(Property property);
        void onReserveClick(Property property);
        void onFavoriteClick(Property property);
    }

    public PropertyAdapter(Context context, List<Property> properties, OnPropertyClickListener listener) {
        this.context = context;
        this.properties = properties;
        this.listener = listener;
    }

    @Override
    public int getItemViewType(int position) {
        if (properties.get(position).isHeader()) {
            return TYPE_HEADER;
        } else {
            return TYPE_PROPERTY;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == TYPE_HEADER) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_property_header, parent, false);
            return new HeaderViewHolder(view);
        } else {
            View view = LayoutInflater.from(context).inflate(R.layout.properties_item, parent, false);
            return new PropertyViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Property property = properties.get(position);

        if (holder instanceof HeaderViewHolder) {
            ((HeaderViewHolder) holder).headerTitle.setText(property.getTitle());
        } else if (holder instanceof PropertyViewHolder) {
            PropertyViewHolder vh = (PropertyViewHolder) holder;
            vh.title.setText(property.getTitle());
            vh.location.setText(property.getLocation());
            vh.price.setText("$" + property.getPrice());
            vh.description.setText(property.getDescription());
            Glide.with(context).load(property.getImageUrl()).into(vh.image);

            vh.itemView.setOnClickListener(v -> listener.onPropertyClick(property));
            vh.reserveBtn.setOnClickListener(v -> listener.onReserveClick(property));
            vh.favoriteBtn.setOnClickListener(v -> listener.onFavoriteClick(property));
        }
    }

    @Override
    public int getItemCount() {
        return properties.size();
    }

    public void setProperties(List<Property> properties) {
        this.properties = properties;
        notifyDataSetChanged();
    }

    static class HeaderViewHolder extends RecyclerView.ViewHolder {
        TextView headerTitle;
        public HeaderViewHolder(@NonNull View itemView) {
            super(itemView);
            headerTitle = itemView.findViewById(R.id.headerTitle);
        }
    }

    static class PropertyViewHolder extends RecyclerView.ViewHolder {
        TextView title, location, price, description;
        ImageView image;
        Button reserveBtn, favoriteBtn;

        public PropertyViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.propertyImage);
            title = itemView.findViewById(R.id.propertyTitle);
            location = itemView.findViewById(R.id.propertyLocation);
            price = itemView.findViewById(R.id.propertyPrice);
            description = itemView.findViewById(R.id.propertyDescription);
            reserveBtn = itemView.findViewById(R.id.reserveButton);
            favoriteBtn = itemView.findViewById(R.id.favoriteButton);
        }
    }
}
