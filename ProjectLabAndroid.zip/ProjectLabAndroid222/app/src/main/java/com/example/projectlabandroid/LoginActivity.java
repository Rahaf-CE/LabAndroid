package com.example.projectlabandroid;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText emailEdit, passwordEdit;
    CheckBox rememberMeCheckbox;
    Button loginBtn;
    DataBaseHelper db;
    TextView  goRegisterBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailEdit = findViewById(R.id.editEmailLogin);
        passwordEdit = findViewById(R.id.editPasswordLogin);
        rememberMeCheckbox = findViewById(R.id.checkboxRememberMe);
        loginBtn = findViewById(R.id.btnLogin);
        goRegisterBtn = findViewById(R.id.goRegister);
        db = new DataBaseHelper(this);

        // Restore saved email if "Remember Me" was used
        SharedPreferences prefs = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        String rememberedEmail = prefs.getString("rememberedEmail", null);
        if (rememberedEmail != null) {
            emailEdit.setText(rememberedEmail);
            rememberMeCheckbox.setChecked(true);
        }

        loginBtn.setOnClickListener(v -> handleLogin());
        goRegisterBtn.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
        });
    }

    private void handleLogin() {
        String email = emailEdit.getText().toString().trim();
        String password = passwordEdit.getText().toString();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both email and password", Toast.LENGTH_SHORT).show();
            return;
        }

        if (db.validateUser(email, password)) {
            // Save login session
            SharedPreferences prefs = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("loggedInEmail", email); // session

            if (rememberMeCheckbox.isChecked()) {
                editor.putString("rememberedEmail", email); // remember email
            } else {
                editor.remove("rememberedEmail");
            }

            editor.apply();

            // Redirect based on role
            String role = db.getUserRole(email);
            if (role.equals("admin")) {
                startActivity(new Intent(this, AdminHomeActivity.class));
            } else {
                startActivity(new Intent(this, Home.class));
            }
            finish();

        } else {
            Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show();
        }
    }
}
