package com.example.projectlabandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.regex.Pattern;

public class RegisterActivity extends AppCompatActivity {

    EditText emailEdit, firstNameEdit, lastNameEdit, passwordEdit, confirmPasswordEdit, phoneEdit;
    Spinner genderSpinner, countrySpinner, citySpinner;
    Button registerBtn;

    HashMap<String, String[]> countryCityMap = new HashMap<>();
    HashMap<String, String> countryCodeMap = new HashMap<>();

    DataBaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initialize views
        emailEdit = findViewById(R.id.editEmail);
        firstNameEdit = findViewById(R.id.editFirstName);
        lastNameEdit = findViewById(R.id.editLastName);
        passwordEdit = findViewById(R.id.editPassword);
        confirmPasswordEdit = findViewById(R.id.editConfirmPassword);
        phoneEdit = findViewById(R.id.editPhone);
        genderSpinner = findViewById(R.id.spinnerGender);
        countrySpinner = findViewById(R.id.spinnerCountry);
        citySpinner = findViewById(R.id.spinnerCity);
        registerBtn = findViewById(R.id.btnRegister);

        db = new DataBaseHelper(this); // Initialize DB

        // Gender Spinner
        String[] genders = {"Male", "Female"};
        genderSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, genders));

        // Country and City Mapping
        countryCityMap.put("Palestine", new String[]{"Ramallah", "Gaza", "Nablus"});
        countryCityMap.put("Jordan", new String[]{"Amman", "Zarqa", "Irbid"});
        countryCityMap.put("Syria", new String[]{"Damascus", "Homs", "Latakia"});
        countryCodeMap.put("Palestine", "+970");
        countryCodeMap.put("Jordan", "+962");
        countryCodeMap.put("Syria", "+963");

        // Populate country spinner
        countrySpinner.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                countryCityMap.keySet().toArray(new String[0])));

        // On country select, set city options + phone prefix
        countrySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCountry = parent.getItemAtPosition(position).toString();
                citySpinner.setAdapter(new ArrayAdapter<>(RegisterActivity.this,
                        android.R.layout.simple_spinner_dropdown_item,
                        countryCityMap.get(selectedCountry)));
                phoneEdit.setText(countryCodeMap.get(selectedCountry)); // Auto fill phone prefix
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        // Register button logic
        registerBtn.setOnClickListener(v -> validateAndRegister());
    }

    private void validateAndRegister() {
        String email = emailEdit.getText().toString().trim();
        String firstName = firstNameEdit.getText().toString().trim();
        String lastName = lastNameEdit.getText().toString().trim();
        String password = passwordEdit.getText().toString();
        String confirmPassword = confirmPasswordEdit.getText().toString();
        String phone = phoneEdit.getText().toString().trim();
        String gender = genderSpinner.getSelectedItem().toString();
        String country = countrySpinner.getSelectedItem().toString();
        String city = citySpinner.getSelectedItem().toString();

        // Validation
        if (!Pattern.matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+", email)) {
            emailEdit.setError("Invalid email format");
            return;
        }

        if (firstName.length() < 3) {
            firstNameEdit.setError("First name must be at least 3 characters");
            return;
        }

        if (lastName.length() < 3) {
            lastNameEdit.setError("Last name must be at least 3 characters");
            return;
        }

        if (!Pattern.matches("^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@#$%^&+=!]).{6,}$", password)) {
            passwordEdit.setError("Password must be 6+ chars, with 1 letter, 1 number, 1 special char");
            return;
        }

        if (!password.equals(confirmPassword)) {
            confirmPasswordEdit.setError("Passwords do not match");
            return;
        }

        if (db.isUserExists(email)) {
            emailEdit.setError("Email already registered");
            return;
        }

        // Insert into DB
        boolean success = db.insertUser(email, firstName, lastName, password, phone, gender, country, city);

        if (success) {
            Toast.makeText(this, "Registered Successfully!", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        } else {
            Toast.makeText(this, "Registration failed. Try again.", Toast.LENGTH_SHORT).show();
        }
    }
}
