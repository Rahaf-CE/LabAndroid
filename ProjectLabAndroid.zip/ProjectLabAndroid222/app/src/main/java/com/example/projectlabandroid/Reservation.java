package com.example.projectlabandroid;
import java.io.Serializable;

public class Reservation implements Serializable {
    private String title, location, price, dateTime, imageUrl;
    private Property property;

    public Reservation(String title, String location, String price, String dateTime, String imageUrl) {
        this.title = title;
        this.location = location;
        this.price = price;
        this.dateTime = dateTime;
        this.imageUrl = imageUrl;
    }

    public Reservation() {

    }

    public Property getProperty() {
        return property;
    }

    public void setProperty(Property property) {
        this.property = property;
    }

    public String getTitle() { return title; }
    public String getLocation() { return location; }
    public String getPrice() { return price; }
    public String getDateTime() { return dateTime; }
    public String getImageUrl() { return imageUrl; }

    public String getType() {
        return "";
    }
}



