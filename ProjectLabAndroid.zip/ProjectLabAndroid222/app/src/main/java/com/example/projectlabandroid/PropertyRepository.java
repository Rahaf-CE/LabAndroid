package com.example.projectlabandroid;

import java.util.ArrayList;
import java.util.List;

public class PropertyRepository {

    public static List<Property> getAll() {
        List<Property> properties = new ArrayList<>();

        properties.add(new Property("106", "Compact Studio Apartment", "Affordable studio perfect for singles or students.", 45000, "Gaza, Palestine", "https://images.unsplash.com/photo-1722604676100-c5e29d41ef50?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"));
        properties.get(properties.size() - 1).setType("Apartment");

        properties.add(new Property("115", "Compact Apartment Near University", "Convenient apartment perfect for students.", 70000, "Jerusalem, Palestine", "https://plus.unsplash.com/premium_photo-1663089331117-b4176fef4c9a?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"));
        properties.get(properties.size() - 1).setType("Apartment");

        properties.add(new Property("101", "Modern 2-Bedroom Apartment", "Beautiful apartment with city view, close to shopping malls.", 85000, "Ramallah, Palestine", "https://images.unsplash.com/photo-1581209410127-8211e90da024?q=80&w=1935&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"));
        properties.get(properties.size() - 1).setType("Apartment");

        properties.add(new Property("109", "Family Apartment with Garden View", "Spacious apartment with access to a shared garden.", 99000, "Bethlehem, Palestine", "https://images.unsplash.com/photo-1626965556114-27c91c051269?q=80&w=1964&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"));
        properties.get(properties.size() - 1).setType("Apartment");

        properties.add(new Property("104", "Penthouse Apartment with Roof Access", "Luxury penthouse with rooftop terrace.", 140000, "Nablus, Palestine", "https://images.unsplash.com/photo-1633579435992-b4c1e88d3f14?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"));
        properties.get(properties.size() - 1).setType("Apartment");

        properties.add(new Property("112", "Luxury City Apartment", "Modern apartment in the city center.", 160000, "Amman, Jordan", "https://plus.unsplash.com/premium_photo-1676636551945-0f9a83dadbb1?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"));
        properties.get(properties.size() - 1).setType("Apartment");

        properties.add(new Property("118", "Seaview Apartment", "Apartment with a stunning view of the sea.", 180000, "Acre, Palestine", "https://images.unsplash.com/photo-1645466463940-317b0b2285c9?q=80&w=1935"));
        properties.get(properties.size() - 1).setType("Apartment");

        properties.add(new Property("108", "Agricultural Land", "Land suitable for farming and agriculture.", 95000, "Homs, Syria", "https://images.unsplash.com/photo-1645727527850-22895e706531?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"));
        properties.get(properties.size() - 1).setType("Land");

        properties.add(new Property("103", "Residential Land Plot", "Prime land suitable for residential development.", 120000, "Aleppo, Syria", "https://plus.unsplash.com/premium_photo-1728309313243-398813f421db?q=80&w=2072&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"));
        properties.get(properties.size() - 1).setType("Land");

        properties.add(new Property("111", "Urban Residential Land", "Land located near city amenities and services.", 135000, "Damascus, Syria", "https://media.istockphoto.com/id/1287183704/photo/vacations-in-poland-new-housing-estate-in-swinoujscie.jpg?s=1024x1024&w=is&k=20&c=Qkm2CvVIXd8aVGI4343wErwfVO0fcs1udWA7nAZC_pU="));
        properties.get(properties.size() - 1).setType("Land");

        properties.add(new Property("113", "Seaside Land Plot", "Land close to the beach, ideal for resorts.", 250000, "Latakia, Syria", "https://plus.unsplash.com/premium_photo-1675721844287-229c75cda217?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"));
        properties.get(properties.size() - 1).setType("Land");

        properties.add(new Property("117", "Industrial Land Plot", "Land suited for industrial development.", 300000, "Industrial Zone, Gaza", "https://media.istockphoto.com/id/2184748571/photo/bungalow-in-northumberland-village.jpg?s=1024x1024&w=is&k=20&c=0Rxpdsl_86CX36cc5R4Y-j5OzUF4_hONRPekRbsA8bs="));
        properties.get(properties.size() - 1).setType("Land");

        properties.add(new Property("107", "Country Style Villa", "Villa with large outdoor area and rustic charm.", 320000, "Zarqa, Jordan", "https://images.unsplash.com/photo-1676794944553-399cade9cd39?q=80&w=1932&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"));
        properties.get(properties.size() - 1).setType("Villa");

        properties.add(new Property("114", "Duplex Family Home", "Modern duplex villa with private backyard.", 370000, "Ramallah, Palestine", "https://images.unsplash.com/photo-1583430691214-abff69c2748a?q=80&w=2075&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"));
        properties.get(properties.size() - 1).setType("Villa");

        properties.add(new Property("102", "Luxury Family Villa", "Spacious villa with private pool and large garden.", 450000, "Amman, Jordan", "https://images.unsplash.com/photo-1723012186489-d809b18c9ffc?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"));
        properties.get(properties.size() - 1).setType("Villa");

        properties.add(new Property("110", "Mountain View Villa", "Villa with stunning mountain views.", 510000, "Ajloun, Jordan", "https://images.unsplash.com/photo-1579524610238-f5e8681d2372?q=80&w=1975&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"));
        properties.get(properties.size() - 1).setType("Villa");

        properties.add(new Property("105", "Beachside Villa", "Elegant beachfront villa with panoramic sea views.", 600000, "Latakia, Syria", "https://images.unsplash.com/photo-1643319602530-7425f2168125?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"));
        properties.get(properties.size() - 1).setType("Villa");

        properties.add(new Property("116", "Luxury Resort Villa", "High-end villa located in a luxury resort.", 850000, "Aqaba, Jordan", "https://plus.unsplash.com/premium_photo-1661962769148-fbe587e60fb8?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"));
        properties.get(properties.size() - 1).setType("Villa");
        Property p = new Property("105", "Beachside Villa", "...", 600000, "Latakia, Syria", "https://images.unsplash.com/photo-1643319602530-7425f2168125?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D");
        p.setType("Villa");
        p.setFeatured(true);  // 👈 Mark as featured
        properties.add(p);

        return properties;
    }
}