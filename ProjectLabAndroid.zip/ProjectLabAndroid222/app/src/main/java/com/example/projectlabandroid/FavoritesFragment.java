package com.example.projectlabandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FavoritesFragment extends Fragment {

    private RecyclerView recyclerView;
    private PropertyAdapter adapter;
    private SharedPrefManager sharedPrefManager;
    private TextView emptyText;

    public FavoritesFragment() {}

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favorites, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewFavorites);
        emptyText = view.findViewById(R.id.emptyFavoritesText);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        sharedPrefManager = new SharedPrefManager(getContext());

        loadFavorites();
        return view;
    }

    private void loadFavorites() {
        List<Property> allFavorites = sharedPrefManager.getFavoriteProperties();

        if (allFavorites.isEmpty()) {
            emptyText.setVisibility(View.VISIBLE);
        } else {
            emptyText.setVisibility(View.GONE);
        }

        // Group by type (Apartment, Villa, Land)
        Map<String, List<Property>> groupedMap = new HashMap<>();
        for (Property p : allFavorites) {
            if (!groupedMap.containsKey(p.getType())) {
                groupedMap.put(p.getType(), new ArrayList<>());
            }
            groupedMap.get(p.getType()).add(p);
        }

        List<Property> groupedList = new ArrayList<>();
        for (String type : groupedMap.keySet()) {
            Property header = new Property("header", type, "", 0, "", "");
            header.setIsHeader(true);
            groupedList.add(header);
            groupedList.addAll(groupedMap.get(type));
        }

        adapter = new PropertyAdapter(getContext(), groupedList, new PropertyAdapter.OnPropertyClickListener() {
            @Override
            public void onPropertyClick(Property property) {
                Intent intent = new Intent(getContext(), PropertyDetailActivity.class);
                intent.putExtra("property", property);
                startActivity(intent);
            }
            @Override
            public void onReserveClick(Property property) {
                Intent intent = new Intent(getContext(), ReservationActivity.class);
                intent.putExtra("property", property);
                startActivity(intent);
            }

            @Override
            public void onFavoriteClick(Property property) {
                sharedPrefManager.removeFavorite(property.getId());
                loadFavorites();
            }
        });

        recyclerView.setAdapter(adapter);
    }
}
